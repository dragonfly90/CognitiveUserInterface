This folder contains the zipped SIMCog server software. To easily import and run the server import the server into Eclipse from .zip form. Additional information on what is each folder can be found in respective readMe files.

If you didn’t want to use eclipse then unzip and take the .java files from the src folder and add them to the project. Add all .jar libraries in CurrentLibs to your project.